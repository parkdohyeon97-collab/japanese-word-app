import { initializeApp } from "https://www.gstatic.com/firebasejs/12.17.0/firebase-app.js";

import {
  getFirestore,
  collection,
  addDoc,
  deleteDoc,
  doc,
  onSnapshot,
  query,
  orderBy,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.17.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyBLnuj2FAWI1mqLG_82KACdkefCxDHixRw",
  authDomain: "japanese-word-app.firebaseapp.com",
  projectId: "japanese-word-app",
  storageBucket: "japanese-word-app.firebasestorage.app",
  messagingSenderId: "941313122107",
  appId: "1:941313122107:web:0d5ec53a2dbbcf8996e11e"
};

const firebaseApp = initializeApp(firebaseConfig);
const db = getFirestore(firebaseApp);

const sharedItemsCollection = collection(db, "sharedItems");

export function listenToSharedItems(onItemsChanged, onError) {
  const sharedItemsQuery = query(
    sharedItemsCollection,
    orderBy("createdAt", "asc")
  );

  return onSnapshot(
    sharedItemsQuery,
    snapshot => {
      const items = snapshot.docs.map(itemDocument => ({
        id: itemDocument.id,
        ...itemDocument.data()
      }));

      onItemsChanged(items);
    },
    error => {
      console.error("공유 단어 불러오기 실패:", error);

      if (onError) {
        onError(error);
      }
    }
  );
}

export async function addSharedItem(item) {
  const cleanedItem = {
    category: item.category || "word",
    word: String(item.word || "").trim(),
    reading: String(item.reading || "").trim(),
    meaning: String(item.meaning || "").trim(),
    example: String(item.example || "").trim(),
    addedBy: String(item.addedBy || "도현").trim(),
    createdAt: serverTimestamp()
  };

  if (!cleanedItem.word) {
    throw new Error("단어나 표현을 입력해 주세요.");
  }

  return addDoc(sharedItemsCollection, cleanedItem);
}

export async function removeSharedItem(itemId) {
  if (!itemId) {
    throw new Error("삭제할 항목의 ID가 없습니다.");
  }

  return deleteDoc(doc(db, "sharedItems", itemId));
}